<p>本项目是一个使用乐鑫ESP32做的开源迷你游戏掌机，支持NES、GB、GBC、GameGear等游戏。</p>
<p> </p>
<p>本项目的硬件设计源自大神pebri86的esplay\_micro\_hardware，</p>
<p>项目地址：https://github.com/pebri86/esplay_micro_hardware</p>
<p> </p>
<p>B站上搬运的相关视频：</p>
<p>https://www.bilibili.com/video/BV1PJ411p7ob?t=90</p>
<p>https://www.bilibili.com/video/BV1354y1i7Gb/</p>
<p> </p>
<p>根据<span class="createUser">Mr_LIGHT建议，将B站上的一个视频地址共享一下，视频评论区置顶处有一个中文固件（我没验证过，有兴趣的自行测试）：</span></p>
<p><a href="https://www.bilibili.com/video/BV11i4y1D7D2" target="_blank">https://www.bilibili.com/video/BV11i4y1D7D2</a></p>
<p> </p>
<p><strong>20230929更新：根据<span class="createUser">Mr_LIGHT </span><span class="createTime">2023-09-20 13:56:55 评论区指出的问题，板子上方两个肩键开关焊盘过孔未金属化，在此之前打的板肩键接触会有问题。目前进行了修正！！！感谢<span class="createUser">Mr_LIGHT！！！</span></span></strong></p>
<p> </p>
<p>前段时间使用立创EDA开源平台中tianle130设计的PCB板在嘉立创打板，自己焊了一个游戏机做测试，可以正常使用。但该PCB板存在部分管脚焊盘悬空的问题（主要是CH340C GND脚焊盘未接地、部分按键管脚焊盘存在线路孤岛问题），另外方向键及AB键使用铜头按扭，比较咯手，游戏性不是太好。而所提供的原理图与PCB板不一致，导致想修正这些问题比较困难。因此在复制原原理图基础上，自行修改部分线路，重新绘制了PCB板，便于大家使用修改完善。</p>
<p>主要改动：</p>
<p>１、使用ESP32WROVER替代原PCB板的ESP32WROOM+外置PSRAM4M方案，因为PSRAM不是太好买，ESP32WROOM+外置PSRAM4M方案对于ESP32WROVER价格上没有优势，且多一块芯片，布线复杂程度也增加一些，其实这个也是这个项目作者pebri86最原来的设计；</p>
<p>2、修改了游戏按键封装，采样6x6x5MM碳膜开关，提升游戏时手感；</p>
<p>3、锂电池充电该为TP4056方案；增加了充电及充满指示灯（不过esplay_micro本身也在屏幕上有充电状态显示，所有不是特别有用，作为选项吧）；</p>
<p>4、采用TYPE-C 和MicroUSB双接口，方便选择使用（2021年9月25日，增加两颗CC1、CC2到地的5.1K电阻，已支持PD协议供电）；</p>
<p>5、使用两个MIC5219 3.3V电源芯片，其中一路专供TFT屏，降低另一路功耗,确保系统稳定；</p>
<p>6、PCB板做了圆角处理，提高裸板使用时的握持手感；</p>
<p>7、增加了插接式TFT的FPC连接器（18P 0.5mm），可支持焊接或插接两种TFT连接方式（不是太实用，2021年9月后取消了这个FPC连接器）；</p>
<p>8、增加了一个背板，可以使用8mm M3尼龙间隔或8mm M3通孔铜柱与主板共同构成一个实用的随身设备。</p>
<p> </p>
<p> </p>
<p>使用时需注意：</p>
<p>1、将JP1短接；</p>
<p>2、TF卡文件目录参考如下（红字部分根据评论区同好<span style="background-color: #ffffff; color: #999999; font-family: sans-serif; font-size: 14px;">fuckfuckfuck<span style="color: #000000;">的建议修订，感谢！</span></span>）：</p>
<p>E:\esplay\firmware\v2.2-esplay-micro.fw</p>
<p><span style="color: #e03e2d;">E:\esplay\data</span></p>
<p>E:\ROMS\NES\1943.NES</p>
<p>E:\ROMS\NES\1944.NES</p>
<p>E:\ROMS\NES\hdl.NES</p>
<p>E:\ROMS\NES\rush.NES</p>
<p>E:\ROMS\NES\tank.NES</p>
<p><span style="color: #e03e2d;">E:\audio\</span>big big world.mp3</p>
<p><span style="color: #e03e2d;">E:\audio\</span>Yesterday Once More - The Carpenters.mp3</p>
<p> </p>
<p>3、写入应用固件后，如暂时没有焊接电池系统显示低电压关机，无法使用USB供电使用，可以焊一根短接线接肖特基二级管负极到电池端口正极端，模拟有电池输入。即可在USB供电情况下使用。</p>
<p> </p>
<p>焊好的一个白色主板（改进了一些，但还不是最新的）：</p>
<p><img src="//image.lceda.cn/pullimage/iRBREj0HK1zJP2JFlZKHf5vHTmLqbHUh4cbITQB2.jpeg" alt="" width="1452" height="791"></p>
<p> </p>
<p>红色的背板配白色主板不就是”红白机“嘛：</p>
<p><img src="//image.lceda.cn/pullimage/S0c4lJqrcwmU2bzZT9UltdFeJQRmff31s7jqgYfM.jpeg" alt=""></p>
<p> </p>
<p>更早一些的一个版本，也是我设计的第一稿，很多不成熟的地方：</p>
<p><img src="//image.lceda.cn/pullimage/yIdT4PHXu10Np038wcsRMPJtdlRuQCsOlnExInNf.jpeg" alt="" width="857" height="510"></p>
<p> </p>
<p>接锂电池，一次点亮：</p>
<p><img src="//image.lceda.cn/pullimage/9vmpC6urAHGwPOXpYA7pZQ3SINurEbNVtP4pJALP.jpeg" alt="" width="1600" height="1427"></p>
<p>两台焊好的设备一起开机：</p>
<p><img src="//image.lceda.cn/pullimage/duTmJjczjtWiKLohrsu5HpGyJ4Yfv4HPo5CmDFY9.jpeg" alt="" width="1347" height="1377"></p>
<p> </p>
<p><strong>Mr_LIGHT  于20221007提供了外壳3D打印文件（3D打印文件见附件），特别感谢！</strong>装配后的效果图如下：</p>
<p><img src="//image.lceda.cn/pullimage/nAu6Nk9FbOJ8bm7lXRN6RwrWiYw2KY6Nv6tmiaE3.jpeg" alt="" width="1920" height="864"></p>
<p>固件下载地址：</p>
<p><a href="https://github.com/pebri86/esplay-base-firmware" target="_blank">https://github.com/pebri86/esplay-base-firmware</a> </p>
<p><a href="https://github.com/pebri86/esplay-retro-emulation" target="_blank">https://github.com/pebri86/esplay-retro-emulation</a> </p>
<p> </p>
<p>中文固件：</p>
<p><a href="https://www.bilibili.com/video/BV11i4y1D7D2" target="_blank">https://www.bilibili.com/video/BV11i4y1D7D2 <span class="createUser" style="color: #000000;">视频评论区置顶处有一个中文固件（我没验证过，有兴趣的自行测试）</span></a></p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。